import {Page, NavController, NavParams} from 'ionic-angular';
import {ItemDetailsPage} from '../item-details/item-details';
import {UserData} from '../../providers/user-data/user-data';


@Page({
    templateUrl: 'build/pages/list/list.html'
})
export class ListPage {
    selectedItem: any;
    // icons: string[];
    //items: Array<{title: string, note: string, icon: string}>;
    itemlists: Array<{ title: string, imagesrc: string, details: string }>;

    constructor(private nav: NavController, navParams: NavParams, private userData: UserData) {
        // If we navigated to this page, we will have an item available as a nav param
        this.itemlists = [];
        this.selectedItem = navParams.get('item');

        this.userData.load().then((value: any) => {
            for (let i = 0; i < value.length; i++) {
                //console.log(i);
                this.itemlists.push({
                    title: value[i].title,
                    imagesrc: value[i].avatar_medium,
                    details: value[i].description
                });
            }
        });

        // this.icons = ['flask', 'wifi', 'beer', 'football', 'basketball', 'paper-plane',
        // 'american-football', 'boat', 'bluetooth', 'build'];

        // this.items = [];
        // for(let i = 1; i < 11; i++) {
        //   this.items.push({
        //     title: 'Item ' + i,
        //     note: 'This is item #' + i,
        //     icon: this.icons[Math.floor(Math.random() * this.icons.length)]
        //   });
    }
}

//   itemTapped(event, item) {
//     this.nav.push(ItemDetailsPage, {
//       item: item
//     });
//   }
// }
